## Packages
framer-motion | For smooth entry animations and list transitions
date-fns | For formatting timestamps nicely

## Notes
The app is designed to be wrapped in Electron.
Window controls (minimize, close) are simulated in the UI for the "frameless" feel if needed, but standard web UI works too.
