import { useState } from "react";
import { useMessages, useCreateMessage } from "@/hooks/use-messages";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Terminal, Loader2, Sparkles, Plus, Rocket, Command } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { InsertMessage } from "@shared/schema";

const formSchema = z.object({
  content: z.string().min(1, "Message cannot be empty").max(500),
});

export default function Dashboard() {
  const { data: messages, isLoading } = useMessages();
  const createMessage = useCreateMessage();
  const { toast } = useToast();
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      content: "",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    createMessage.mutate(values, {
      onSuccess: () => {
        toast({
          title: "Message sent",
          description: "Your thought has been captured.",
        });
        form.reset();
      },
      onError: () => {
        toast({
          title: "Error",
          description: "Failed to send message. Please try again.",
          variant: "destructive",
        });
      },
    });
  }

  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row text-foreground overflow-hidden">
      {/* Sidebar for desktop feeling */}
      <aside className="w-full md:w-64 border-r border-border bg-muted/20 p-6 flex-shrink-0 hidden md:flex flex-col gap-8">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground">
            <Rocket className="w-5 h-5" />
          </div>
          <span className="font-bold text-lg tracking-tight">Workshop App</span>
        </div>
        
        <nav className="flex flex-col gap-2">
          <Button variant="secondary" className="justify-start gap-2 shadow-sm">
            <Terminal className="w-4 h-4" />
            Console
          </Button>
          <Button variant="ghost" className="justify-start gap-2 text-muted-foreground">
            <Command className="w-4 h-4" />
            Settings
          </Button>
        </nav>

        <div className="mt-auto">
          <div className="rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 p-4 border border-primary/10">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="font-semibold text-sm">Pro Tip</span>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">
              This app is ready to be packaged with Electron. Run the build script to create your executable.
            </p>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        
        {/* Header */}
        <header className="h-16 border-b border-border flex items-center px-6 md:px-10 bg-background/80 backdrop-blur-sm z-10 sticky top-0">
          <h1 className="text-lg font-medium">Message Stream</h1>
          <div className="ml-auto flex items-center gap-4">
             <div className="text-xs text-muted-foreground hidden sm:block">
               Connected to local server
             </div>
             <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]"></div>
          </div>
        </header>

        <div className="flex-1 overflow-auto p-4 md:p-10 scroll-smooth">
          <div className="max-w-3xl mx-auto w-full space-y-8 pb-20">
            
            {/* Input Section */}
            <section>
              <Card className="border-border/60 shadow-lg shadow-black/5 bg-gradient-to-b from-card to-card/50">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg font-medium flex items-center gap-2">
                    <Plus className="w-5 h-5 text-primary" />
                    New Entry
                  </CardTitle>
                  <CardDescription>
                    Add a note to the shared workshop stream.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="content"
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <Textarea 
                                placeholder="Type your message here..." 
                                className="resize-none min-h-[100px] bg-background/50 focus:bg-background transition-colors text-base"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <div className="flex justify-end">
                        <Button 
                          type="submit" 
                          disabled={createMessage.isPending}
                          className="px-6 shadow-md hover:shadow-lg transition-all"
                        >
                          {createMessage.isPending ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Sending...
                            </>
                          ) : (
                            <>
                              <Send className="mr-2 h-4 w-4" />
                              Send Message
                            </>
                          )}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </section>

            {/* List Section */}
            <section className="space-y-4">
              <div className="flex items-center justify-between px-1">
                <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Recent Activity</h2>
                <span className="text-xs text-muted-foreground">
                  {messages?.length || 0} messages
                </span>
              </div>
              
              {isLoading ? (
                <div className="flex flex-col gap-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-24 w-full bg-muted/40 animate-pulse rounded-xl" />
                  ))}
                </div>
              ) : (
                <div className="grid gap-4">
                  <AnimatePresence mode="popLayout">
                    {messages && messages.length > 0 ? (
                      messages.map((message: any) => (
                        <motion.div
                          key={message.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, scale: 0.95 }}
                          layout
                          transition={{ duration: 0.2 }}
                        >
                          <div className="group relative bg-card hover:bg-accent/50 border border-border/40 hover:border-border rounded-xl p-5 transition-all duration-200 shadow-sm hover:shadow-md">
                            <div className="flex justify-between items-start gap-4">
                              <p className="text-sm leading-relaxed whitespace-pre-wrap font-normal text-foreground/90">
                                {message.content}
                              </p>
                              <time className="text-[10px] font-mono text-muted-foreground whitespace-nowrap pt-1">
                                {message.createdAt ? format(new Date(message.createdAt), "HH:mm") : ""}
                              </time>
                            </div>
                          </div>
                        </motion.div>
                      ))
                    ) : (
                      <div className="text-center py-20 text-muted-foreground bg-muted/10 rounded-xl border border-dashed border-border">
                        <p>No messages yet. Be the first to post!</p>
                      </div>
                    )}
                  </AnimatePresence>
                </div>
              )}
            </section>

          </div>
        </div>
      </main>
    </div>
  );
}
